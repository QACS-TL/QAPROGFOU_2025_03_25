name = input("Please enter your name: ")
age = input("Please enter your age: ")
my_number = 45

print("Hello " + name + ", you are " + age + " years old")

# Birthday!
age = int(age) + 1
print(age)

can_retire = False
can_retire = age >= 64

if can_retire:
    print("You can retire")

print("All done")


for obj in myList

for i in range(0, 10):
    print(i)

i = 0
while True:
    print(i)
    i = i + 1