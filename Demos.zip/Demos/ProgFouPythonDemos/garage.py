from car import Car

c1 = Car()
c1.make = "Vauxhall"
c1.model = "Corsa"
c1.colour = "Blue"

c2 = Car()

c3 = Car()
c3.make = "Volkswagon"
c3.model = "Beetle"
c3.colour = "Orange"

print(c1.colour)
print(c3.colour)
print(c2.colour)

c1.accelerate(10)
c2.accelerate(30)
c3.accelerate(70)

print(c1.speed)
print(c3.speed)
print(c2.speed)

garage = [c1, c2, c3]
garage.append(c1)
garage.append(c2)
garage.append(c3)

for c in garage:
    c.accelerate(20)

for c in garage:
    print(c.speed)





