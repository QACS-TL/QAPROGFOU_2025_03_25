import time
employee_names = {"akira": "1234", "ade": "2345", "freya": "3456", "mia": "4567"}
messages = ["Please enter your name, Q to quit: ",
            "Please enter your PIN, Q to quit: "]

NAME_PROMPT = 0
PIN_PROMPT = 1
def get_input(message_number):
    return input(messages[message_number]).lower()

# User validatiuon . Asks for name and pin locks you out after 3 PIN attempts
# P Behague
door_status = "LOCKED"
valid_pin = False
name = get_input(NAME_PROMPT) # Prompt for user name
while name != "q":
    if name in employee_names:
        print("Name accepted")
        pin = get_input(PIN_PROMPT)  # Prompt for user PIN
        count = 1
        while pin != "q" and pin != employee_names[name] and count < 3:
            print("invalid PIN! Please try again")
            count += 1
            pin = get_input(PIN_PROMPT)
        if pin == "q":
            break
        if pin == employee_names[name]:
            valid_pin = True
            break
        # invalid pin
        print("Three invalid PIN attempts. System will pause for 5 seconds")
        time.sleep(5)
        name = get_input(NAME_PROMPT)
    else:
        print("invalid Name! Please try again")
        name = get_input(NAME_PROMPT)
if name != "q" and valid_pin:
    print("PIN is valid")
    door_status = "UNLOCKED"
print(f"Door is currently {door_status}")
