balance = 0

def display_balance(bal):
    print("Balance is " + str(bal))
    return bal

balance = 111
balance = display_balance(balance)
print(balance)

