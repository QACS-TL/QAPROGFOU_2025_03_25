from utilities import Prompt_for_name


name = ""
print(Prompt_for_name())
print("We will see this")
Prompt_for_name()
print(name)


