def say_hello(name, title="Ms"):
    # print("Hello World")
    title += "*"
    return f"Hello {title} {name}"


def Prompt_for_name():
    name = input("Please enter your name: ")
    title = input("Please enter your title or use spaces for default: ")

    if title == "":
        return say_hello(name)
    else:
        return say_hello(name, title)