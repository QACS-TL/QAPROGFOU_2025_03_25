import time
employee_names = {"akira": "1234", "ade": "2345", "freya": "3456", "mia": "4567"}

door_status = "LOCKED"
valid_pin = False
name = input("Please enter your name, Q to quit: ").lower()
while name != "q":
    if name in employee_names:
        print("Name accepted")
        pin = input("Please enter your PIN, Q to quit: ").lower()
        count = 1
        while pin != "q" and pin != employee_names[name] and count < 3 :
            print("invalid PIN! Please try again")
            count += 1
            pin = input("Please enter your PIN, Q to quit: ").lower()
        if pin == "q":
            break
        if pin == employee_names[name]:
            valid_pin = True
            break
        print("Three invalid PIN attempts. System will pause for 5 seconds")
        time.sleep(5)
        name = input("Please enter your name, Q to quit: ").lower()
    else:
        print("invalid Name! Please try again")
        name = input("Please enter your name, Q to quit: ").lower()
if name != "q" and valid_pin:
    print("PIN is valid")
    door_status = "UNLOCKED"
print(f"Door is currently {door_status}")
