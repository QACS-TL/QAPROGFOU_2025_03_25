manufacturer = "Ford"
model = "Fiesta"
colour = "Red"
engine_size = 999

print(colour + " " + manufacturer + " " + model + " has an engine size of " + str(engine_size))
print(manufacturer, colour, model, engine_size)


a = 1
b = 10
c = a / b



# print(a + " divided by " + b + " is " + c)
print(f"{a} divided by {b}  is {c:.30f}")
if c == 0.1:
    print("the answer is 1/10th")

