

topFive =["Black Lace", "Noel Edmonds",  "German Person", "Bob the Builder",  "Tinky Winky"]

# topFive.append("Shaddap You Face")

# topFive.sort()

# topFive[3] = "I like bananas"

print(topFive[3])

newtopFive = sorted(topFive)
print(newtopFive)

for performer in topFive:
    print(performer)


for i in range(0, len(topFive)):
    print(f"Song number {i+1} is {topFive[i]}")


a = 6
b = 6
not_result = ""
if a != b:
    not_result = "NOT "

print(f"a and b are {not_result}the same")
print("we will always see this")


count = 0
while True:
    val = input("Please enter a value a, b or c. q to quit")
    if val.lower() == "q":
        break
    print(val)



salary = 49500
highTax = 0
lowTax = 0


if 11850 <= salary <= 46350:
    lowTax += (salary - 11850) * 0.2
else:
    if 46351 <= salary <= 150000:
        lowTax += (46350 - 11850) * 0.2
        highTax += (salary-43000) * 0.4
    else:
        if salary > 150000:
            lowTax += (46350 - 11850) * 0.2
            highTax += (150000 - 46350) * 0.4
            highTax += (salary - 150000) * 0.45
        else:
            print("Tax Free!")
