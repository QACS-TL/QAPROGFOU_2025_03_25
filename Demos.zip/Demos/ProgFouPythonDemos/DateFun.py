import datetime
# calculate no
#
now = datetime.datetime.now()
print("Current date and time:")
print(now.strftime("%Y-%m-%d %H:%M"))
print("Current date:")
print(now.strftime("%d-%m-%Y"))
print("Current time:")
print(now.strftime("%H:%M"))

