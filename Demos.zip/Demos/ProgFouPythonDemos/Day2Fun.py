import math

greeting = "Hello"
target = "World"
message = greeting + " " + target
print(message)

length = len(message) # Length of string
print(message[:])  # prints Hello = chars 0 to 4
uMessage = message.upper() # ?
print(uMessage)

ageString = input("Enter your Age:")

age = int(ageString)
age += 1
print(age)

if age == 22 or length > 60:
    print("TRUE!")



