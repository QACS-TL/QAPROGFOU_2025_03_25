class Car:
    def __init__(self):
       self.make = "Ford"
       self.model = "Fiesta"
       self.colour = "Red"
       self.speed = 0

    def accelerate(self, increment):
        self.speed += increment