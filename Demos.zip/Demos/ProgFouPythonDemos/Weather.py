
# Required libraries.
import sys
import re  # Provides regexp support
import webbrowser  # Provides functions for opening and displaying html content to web browsers.
import requests
# import weather_db
import datetime

API_KEY = "396a2d3386e07f92777ed7fee73f7c67"   # For testing... and to be removed.


def get_weather():
    """ Get weather for a given city, country and return dict """

    city = input("Please enter a city (eg. london): ") or "london"
    country = input("Please enter a country (eg. gb/uk): ") or "gb"

    base_url = r"http://api.openweathermap.org/data/2.5/weather?"
    full_url = f"{base_url}q={city},{country},&appid={API_KEY}"

    try:
        weather_data = requests.get(full_url)
        w_data = weather_data.json()
    except Exception as err:
        # if there was an error opening the url then return error
        print(f"Error: {err.args}", file=sys.stderr)
        return "Error opening url"
    else:
        # if weather_data has message 'city not found' from web server then city is invalid.
        if re.search(r"city not found", weather_data.text):
            print("City Not found", file=sys.stderr)
            return None

    # return the weather condition as a dict.
    return w_data


w_data = get_weather()
print(w_data)