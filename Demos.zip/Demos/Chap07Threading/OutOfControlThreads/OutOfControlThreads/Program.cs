﻿using System;
using System.Threading;
using System.Runtime.CompilerServices;

namespace OutOfControlCS
{

	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Program
	{

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		public static void Main(string[] args)
		{

			int threadCount = 10;

			Thread[] workers = new Thread[threadCount];

			//
			// Change the name of the method in the ThreadStart constructor
			// to see the different behaviours of the classes
			//
			for (int i = 0; i < threadCount; i++)
			{
				workers[i] = new Thread(new ThreadStart(InControl));
				workers[i].Start();
			}


			Console.ReadLine();


			for (int i = 0; i < threadCount; i++)
			{
				workers[i].Abort();
			}

			Console.ReadLine();
		}

		//
		// OutOfControl() - expect garbled output
		//
		static void OutOfControl()
		{
			for (; ; )
			{
				Console.Write("I ");
				Console.Write("love ");
				Console.Write("debugging ");
				Console.Write("multithreaded ");
				Console.Write("programs!");
				Console.WriteLine();
			}
		}


		//
		// InControl() - using Monitor to ensure synchronisation
		//               but it really should have a try {} finally{}
		//               to deal with exceptions
		//
		static void InControl()
		{
			for (; ; )
			{
				Monitor.Enter(typeof(Program));

				Console.Write("I ");
				Console.Write("love ");
				Console.Write("debugging ");
				Console.Write("multithreaded ");
				Console.Write("programs!");
				Console.WriteLine();

				// But what happens if someone calls Abort(), or an
				// exception is thrown?
				// In this case, Exit() won't be called, which will leave
				// the sync object locked.
				// Isn't there something better?

				// Thread.CurrentThread.Abort();

				Monitor.Exit(typeof(Program));
			}
		}

		//
		// BetterInControl() - Rather than add try{} finally{}, we
		// are using the lock() mechanism from C# to do it for us
		//
		static void BetterInControl()
		{
			for (; ; )
			{
				lock (typeof(Program))
				{
					Console.Write("I ");
					Console.Write("love ");
					Console.Write("debugging ");
					Console.Write("multithreaded ");
					Console.Write("programs!");
					Console.WriteLine();
				}
			}
		}

		//
		// AlternativeInControl() - goes a stage further, and uses a
		// helper method, WriteMessage(), that has an attribute to 
		// mark the call as requiring synchronisation
		//		
		static void AlternativeInControl()
		{
			for (; ; )
			{
				WriteMessage();
			}
		}

		[MethodImpl(MethodImplOptions.Synchronized)]
		static void WriteMessage()
		{
			Console.Write("I ");
			Console.Write("love ");
			Console.Write("debugging ");
			Console.Write("multithreaded ");
			Console.Write("programs!");
			Console.WriteLine();
		}
	}
}
