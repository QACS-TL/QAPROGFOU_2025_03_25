import msvcrt
import os
import win32file

#Note: opening a file and it being locked from other users
# is a Windows-specific issue. Unix OSes allow deleting because the OS does NOT
# create locks.

# Note Too: if you need to keep the win32-file open beyond the lifetime
# of the file-handle object returned, you should invoke PyHandle.detach()
# on that handle.

py_handle = win32file.CreateFile(
    '06ShakespeareanQuotes.txt',
    win32file.GENERIC_READ,
    win32file.FILE_SHARE_DELETE
        | win32file.FILE_SHARE_READ
        | win32file.FILE_SHARE_WRITE,
    None,
    win32file.OPEN_EXISTING,
    win32file.FILE_ATTRIBUTE_NORMAL,
    None
)
try:
    with os.fdopen(
        msvcrt.open_osfhandle(py_handle.handle, os.O_RDONLY)
    ) as file_descriptor:
        for line in file_descriptor:
            print(line)

finally:
    py_handle.Detach()
    py_handle.Close()

