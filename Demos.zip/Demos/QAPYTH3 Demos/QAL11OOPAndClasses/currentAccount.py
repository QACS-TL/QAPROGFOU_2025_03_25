import account
class CurrentAccount(account.Account):

    def __init__(self, initial, overdraft_limit):
        super().__init__(initial)
        # self._balance = initial
        self._overdraft_limit = overdraft_limit

    def deposit(self, amt):
        # add interest
        amt = amt * 1.02
        super().deposit(amt)
