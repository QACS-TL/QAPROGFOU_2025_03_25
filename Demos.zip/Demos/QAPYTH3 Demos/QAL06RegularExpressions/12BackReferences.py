import re
# from datetime import date
#
# year = str(date.today())[:4]
#
# strn = 'copyright 2005-2006'
#
# print(re.sub(r'((19|20)[0-9]{2})-((19|20)[0-9]{2})', r'\1-' + year, strn))
# #               ^^^^^^^^^^^^^^^
# print(re.sub(r'((19|20)[0-9]{2})-((19|20)[0-9]{2})', r'\2-' + year, strn))
# #                ^^^^^
# print(re.sub(r'((19|20)[0-9]{2})-((19|20)[0-9]{2})', r'\3-' + year, strn))
# #                                 ^^^^^^^^^^^^^^^
# print(re.sub(r'((19|20)[0-9]{2})-((19|20)[0-9]{2})', r'\4-' + year, strn))
#
# print(re.sub(r'(19|20[0-9]{2})-19|20[0-9]{2}', r'\1-' + year, strn))
#                                  ^^^^^

secret_number = input("Please enter your secret number")
m = re.search("([0-9]+)[a-zA-Z]*([0-9])", secret_number)
if m:
    print(f"It contains digits: {m.groups()[0]}, {m.groups()[1]}")
else:
    print("does not contain digits")

