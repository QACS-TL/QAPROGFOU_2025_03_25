mytuple = 'eggs', 'bacon', 'spam', 'tea'
print(mytuple)
print(mytuple[1])
print(mytuple[-1])

# Can be reassigned but not altered
# mytuple[2] = 'John'
# mytuple.append('fried-slice')

mytuple = 'apples', 'bananas', 'carrots', 'dates'
print(mytuple)