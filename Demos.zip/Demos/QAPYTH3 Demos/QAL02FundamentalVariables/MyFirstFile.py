
def print_my_name(my_name):
    print(my_name)


first_name = "Pete"
surname = "Behague"
full_name = first_name + " " + surname
print_my_name(full_name)
