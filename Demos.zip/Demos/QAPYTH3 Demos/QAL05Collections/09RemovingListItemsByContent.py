cheese = ['Cheddar', 'Stilton', 'Cornish Yarg',
          'Oke', 'Devon Blue']
cheese.remove('Oke')
print(cheese)

# No Brie so throws exception
cheese.remove('Brie')
