import glob
import os

pattern = r'C:\Windows\*'
for fname in (filter(os.path.isdir, glob.iglob(pattern))):
    print(fname)

