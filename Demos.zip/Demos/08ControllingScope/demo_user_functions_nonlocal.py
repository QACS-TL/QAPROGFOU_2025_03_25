import sys

knight = "King Arthur"


def who_goes_next(knight):
    """ Who is next to walk the bridge of death? """
    # global knight
    knight = "Sir Robin" # Really?

    def brave_knights(knight):
        # nonlocal knight
        # global knight
        knight = "Sir Lancelot" # Ofcourse, Lancelot is far braver!
        print(knight)

    brave_knights(knight)
    print(f"{knight} will go next")


""" Who goes there? """
who_goes_next(knight)
print(f"{knight} will go next")
