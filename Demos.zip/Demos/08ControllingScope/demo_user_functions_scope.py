import sys

message = "What...is your favourite colour?"

# Display a given greeting to a recipients
def say_hello(greeting="welcome", recipient="brave knights"):
    # global message  # Try executing with and without this line commented.
    # An assignment to message forces Python to create a new local object.
    message = str(greeting) + " " + str(recipient)
    print(message)


say_hello("my message", "Arthur")
print(message)


